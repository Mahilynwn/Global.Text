<?php 
require_once 'db_connect.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conexion->prepare("SELECT u.*, c.descripcion as cargo_descripcion FROM users u JOIN cargo c ON u.id_cargo = c.id WHERE u.email = ?");
    
    if ($stmt === false) {
        die("Error en la preparación de la consulta: " . $conexion->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        // Iniciar sesión y establecer datos del usuario
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_cargo'] = $user['id_cargo'];
        $_SESSION['user_cargo_descripcion'] = $user['cargo_descripcion'];
        
        // Verificar el cargo del usuario
        if ($user['id_cargo'] == 1) { // Asumiendo que 1 es el id para Administrador
            header("Location: admin/admin.php"); // Redirige al panel de admin
        } elseif ($user['id_cargo'] == 2) { // Asumiendo que 2 es el id para Cliente
            header("Location: account.php"); // Redirige al panel de cliente
        } else {
            header("Location: index.php"); // Redirige al dashboard general si no tiene un cargo específico
        }
        exit();
    } else {
        // Credenciales inválidas
        header("Location: login.php?error=invalid_credentials");
        exit();
    }

    $stmt->close();
}

$conexion->close();
?>