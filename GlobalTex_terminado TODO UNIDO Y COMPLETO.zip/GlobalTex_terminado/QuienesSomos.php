<php>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GlobalTex - Colombia</title>
    <link rel="stylesheet" href="css/Style.css">
    <link rel="shortcut icon" href="empresa MM&M.jpg" type="image/x-icon">

    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="img/empresa MM_M.jpg" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css"
        media="screen">
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />


    <header>
        <a href="#" target="_blank" class="logo"><img src="img/empresa MM_M.jpg" alt="logo">
            <h2 class="nombre-empresa">GlobalTex</h2>
        </a>

        <nav class="navbar navbar-expand-lg navbar-dark bg-transparent">
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Inicio <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Estampados</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Promociones</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contacto</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.html">Iniciar sesión</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>

</head>

<body class="body_QS">

    <h1 class="Quienesomos_H1">Palabras del Creador</h1>
    <h2 class="Quienesomos_H2">
        <p class="Quienesomos_P">GlobalText Colombia, es una micro-empresa la cual se basa en la impresión de bordados en distintas prendas de
            vestir, su temática es opcional, es decir, abarcan todos los temas posibles que le gusten a la comunidad,
            también abarcan los eventos y fechas especiales como lo son navidad o San Valentín. En esta oportunidad, la
            micro-empresa ha colaborado con los aprendices del SENA, la cual se hacen llamar MM&M (Mahily, Mateo,
            Molina), cuyo propósito fue crear un sitio web el cual promocionara sus productos, donde muestren diversos
            catálogos y los diseños de bordados. Usted podrá contar con los servicios de Global Text para ordenar su
            prenda o si usted considera, crear tu propio diseño de prenda a tu manera. Con los aprendices M,M&M y con el
            administrador de GlobalText (Ramiro Ramírez) esperamos ser de tus sitios favoritos y que esta web se la
            recomiendes a los mas cercanos</p>
    </h2>

    <h1 class="Quienesomos_H1">Palabras de la micro-empresa</h1>
    <h2 class="Quienesomos_H2">
        <p class="Quienesomos_P">M,M&M (Mahily, Mateo y Molina) Son un grupo de aprendices del Servicio Nacional de Aprendizaje (SENA) cuyo
            objetivo desde un inicio era apoyar a una micro-empresa en mejorar la venta de sus productos a través de un
            sitio web, para ello tuvimos que solicitar el permiso de la micro-empresa de GlobalText para tomar de
            referencia todos sus catálogos y adaptarnos a sus políticas de privacidad para crear este sitio web, con
            ayuda del administrador Ramiro Ramírez buscaremos adaptamos a un sitio cómodo que sea fácil de manejar para
            todos los usuarios.</p>
    </h2>

            <!--Inicio de footer-->
            <footer class="footer">
                <div class="footer__addr">
                   <h1 class="footer__logo">derechos</h1>
 
                   <h2>Contacteme</h2>
 
                   <address>
                      Dueño: Ramiro Ramirez<br>
 
                      <a class="footer__btn" href="jm8052932@gmail.com">Mi correo</a>
                   </address>
                </div>
 
                <ul class="footer__nav">
                   <li class="nav__item">
                      <h2 class="nav__title">Quienes somos</h2>
 
                      <ul class="nav__ul">
                         <li>
                            <a href="#">Pagina Principal</a>
                         </li>
 
                         <li>
                            <a href="#">Contactenos</a>
                         </li>
 
                         <li>
                            <a href="#">Soporte Tecnico</a>
                         </li>
                      </ul>
                   </li>
 
                   <li class="nav_item nav_item--extra">
                      <h2 class="nav__title">Autores</h2>
 
                      <ul class="nav_ul nav_ul--extra">
                         <li>
                            <a href="#">Mahily Gutierrez</a>
                         </li>
 
                         <li>
                            <a href="#">Juan Molina Murcia</a>
                         </li>
 
                         <li>
                            <a href="#">Andres Mateo Rodriguez</a>
                         </li>
 
                      </ul>
                   </li>
 
                   <li class="nav__item">
                      <h2 class="nav__title">Legal</h2>
 
                      <ul class="nav__ul">
                         <li>
                            <a href="#">Politica De Privacidad</a>
                         </li>
 
                         <li>
                            <a href="#">Terminos De Uso</a>
                         </li>
 
                         <li>
                            <a href="#">Servicio Tenico</a>
                         </li>
                      </ul>
                   </li>
                </ul>
 
                <div class="legal">
                   <p>&copy; año 2023. Todos los derechos reservados.</p>
 
                   <div class="legal__links">
                      <span>Creado por <span class="heart">♥</span> MM&M programadores iniciales</span>
                   </div>
                </div>
             </footer>
             <!-- Fin de footer-->
 

    <!-- Javascript files-->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery-3.0.0.min.js"></script>
    <!-- sidebar -->
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/custom.js"></script>
    <!-- javascript -->
    <script src="js/owl.carousel.js"></script>
    <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <script>
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4'
        });
    </script>

</body>

      </php>