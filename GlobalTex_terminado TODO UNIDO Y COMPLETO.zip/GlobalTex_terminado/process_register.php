<?php
require_once 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $direccion = $_POST['Direccion'];  // Añadido para capturar la dirección

    $stmt = $conexion->prepare("INSERT INTO users (name, email, password, direccion) VALUES (?, ?, ?, ?)");
    
    if ($stmt === false) {
        die("Error en la preparación de la consulta: " . $conexion->error);
    }

    $stmt->bind_param("ssss", $name, $email, $password, $direccion);
    
    try {
        if ($stmt->execute()) {
            // Iniciar sesión y establecer datos del usuario
            session_start();
            $_SESSION['user_id'] = $conexion->insert_id;
            $_SESSION['user_name'] = $name;

            // Redirigir a la página de inicio
            header("Location: index.php?registration=success");
            exit();
        } else {
            throw new Exception("Error al ejecutar la consulta: " . $stmt->error);
        }
    } catch(Exception $e) {
        // Manejar el error (por ejemplo, email duplicado)
        echo "Error: " . $e->getMessage();
    }

    $stmt->close();
}

$conexion->close();
?>