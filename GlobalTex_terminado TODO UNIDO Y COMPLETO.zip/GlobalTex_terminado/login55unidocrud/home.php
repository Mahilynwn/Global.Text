<?php include('session.php'); ?>
<?php include('header.php'); ?>
<body>
<div class="container">
	<div style="height:50px;">
	</div>
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
           <h2>Welcome, <?php echo $user; ?>!</h2>
           <a href="logout.php" class="btn btn-danger"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
           <a href="crud_php/index.php" class="btn btn-primary"><span class="glyphicon glyphicon-log-out"></span>Modulo de Clientes</a>
        </div>
    </div>
</div>
</body>
</html>