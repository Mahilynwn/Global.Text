<php>

<!DOCTYPE html>
<html lang="es">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>GlobalTex - Colombia</title>
   <link rel="stylesheet" href="css/Style.css">
   <link rel="shortcut icon" href="empresa MM&M.jpg" type="image/x-icon">

   <!-- bootstrap css -->
   <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
   <!-- style css -->
   <link rel="stylesheet" type="text/css" href="css/style.css">
   <!-- Responsive-->
   <link rel="stylesheet" href="css/responsive.css">
   <!-- fevicon -->
   <link rel="icon" href="img/empresa MM_M.jpg" type="image/gif" />
   <!-- Scrollbar Custom CSS -->
   <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
   <!-- Tweaks for older IEs-->
   <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
   <!-- owl stylesheets -->
   <link rel="stylesheet" href="css/owl.carousel.min.css">
   <link rel="stylesheet" href="css/owl.theme.default.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css"
      media="screen">
   <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />


   <header>
      <a href="#" target="_blank" class="logo"><img src="img/empresa MM_M.jpg" alt="logo">
         <h2 class="nombre-empresa">GlobalTex</h2>
      </a>

      <nav class="navbar navbar-expand-lg navbar-dark bg-transparent">
         <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
               <li class="nav-item active">
                  <a class="nav-link" href="index.php">Inicio <span class="sr-only">(current)</span></a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#">Estampados</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#">Promociones</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#">Contacto</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="login.php">Iniciar sesión</a>
               </li>
            </ul>
         </div>
      </nav>
   </header>

</head>
<body>
   <div class="movies_section layout_padding">
      <div class="container">
         <div class="movies_menu">
            <ul>
               <li><a href="TodosLosEstilos.php">Todos los estilos</a></li>
               <li class="active"><a href="#">Anime</a></li>
               <li><a href="#">Terror</a></li>
               <li><a href="CatalogoVideoJuegos.php">VideoJuegos</a></li>
            </ul>
         </div>
         <h2 class="letest_text">DRAGON BALL</h2>
         <div class="movies_main">
            <div class="iamge_movies_main">
               <div class="iamge_movies">
                  <div class="image_3">
                     <img src="img/dragonBall1.jpg" class="image" style="width:100%">
                     <div class="middle">
                        <button class="playnow_bt"><a href="DragonBallA.php">Comprar ya!!</button></a>
                     </div>
                  </div>
                  <h1 class="code_text">Buso Estampado Goku</h1>
                  <p class="there_text">Serie favorita de algunos</p>
                  <div class="star_icon">
                     <ul>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                     </ul>
                  </div>
               </div>
               <div class="iamge_movies">
                  <div class="image_3">
                     <img src="img/Naruto1.jpg" class="image" style="width:100%">
                     <div class="middle">
                        <button class="playnow_bt">Ver estilos</button>
                     </div>
                  </div>
                  <h1 class="code_text">Naruto</h1>
                  <p class="there_text">Serie favorita #2 de algunos</p>
                  <div class="star_icon">
                     <ul>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                     </ul>
                  </div>
               </div>
               <div class="iamge_movies">
                  <div class="image_3">
                     <img src="img/OnePieceGeneral.jpeg" class="image" style="width:100%">
                     <div class="middle">
                        <button class="playnow_bt">Ver estilos</button>
                     </div>
                  </div>
                  <h1 class="code_text">One Piece</h1>
                  <p class="there_text">Muy largo xd</p>
                  <div class="star_icon">
                     <ul>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                     </ul>
                  </div>
               </div>
               <div class="iamge_movies">
                  <div class="image_3">
                     <img src="img/KimetsunoYaibaGeneral.jpeg" class="image" style="width:100%">
                     <div class="middle">
                        <button class="playnow_bt">Ver estilos</button>
                     </div>
                  </div>
                  <h1 class="code_text">Kimetsu No Yaiba</h1>
                  <p class="there_text">Demonios y caza demonios</p>
                  <div class="star_icon">
                     <ul>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                     </ul>
                  </div>
               </div>
               <div class="iamge_movies">
                  <div class="image_3">
                     <img src="img/ShingekiNoKyojinGeneral.jpeg" class="image" style="width:100%">
                     <div class="middle">
                        <button class="playnow_bt">Ver estilos</button>
                     </div>
                  </div>
                  <h1 class="code_text">Shingeki No Kyojin</h1>
                  <p class="there_text">Titanes y caza titanes</p>
                  <div class="star_icon">
                     <ul>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                        <li><a href="#"><img src="img/icon-2.png"></a></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>



                     <!--Inicio de footer-->
                     <footer class="footer">
                        <div class="footer__addr">
                           <h1 class="footer__logo">derechos</h1>
         
                           <h2>Contacteme</h2>
         
                           <address>
                              Dueño: Ramiro Ramirez<br>
         
                              <a class="footer__btn" href="#@gmail.com">Mi correo</a>
                           </address>
                        </div>
         
                        <ul class="footer__nav">
                           <li class="nav__item">
                              <h2 class="nav__title">Quienes somos</h2>
         
                              <ul class="nav__ul">
                                 <li>
                                    <a href="QuienesSomos.php">"Pagina Principal"</a>
                                 </li>
         
                                 <li>
                                    <a href="#">Contactenos</a>
                                 </li>
         
                                 <li>
                                    <a href="#">Soporte Tecnico</a>
                                 </li>
                              </ul>
                           </li>
         
                           <li class="nav_item nav_item--extra">
                              <h2 class="nav__title">Autores</h2>
         
                              <ul class="nav_ul nav_ul--extra">
                                 <li>
                                    <a href="#">Mahily Gutierrez</a>
                                 </li>
         
                                 <li>
                                    <a href="#">Juan Molina Murcia</a>
                                 </li>
         
                                 <li>
                                    <a href="#">Andres Mateo Rodriguez</a>
                                 </li>
         
                              </ul>
                           </li>
         
                           <li class="nav__item">
                              <h2 class="nav__title">Legal</h2>
         
                              <ul class="nav__ul">
                                 <li>
                                    <a href="#">Politica De Privacidad</a>
                                 </li>
         
                                 <li>
                                    <a href="#">Terminos De Uso</a>
                                 </li>
         
                                 <li>
                                    <a href="#">Servicio Tenico</a>
                                 </li>
                              </ul>
                           </li>
                        </ul>
         
                        <div class="legal">
                           <p>&copy; año 2023. Todos los derechos reservados.</p>
         
                           <div class="legal__links">
                              <span>Creado por <span class="heart">♥</span> MM&M programadores iniciales</span>
                           </div>
                        </div>
                     </footer>
                     <!-- Fin de footer-->
         
                                    <!-- Javascript files-->
               <script src="js/jquery.min.js"></script>
               <script src="js/popper.min.js"></script>
               <script src="js/bootstrap.bundle.min.js"></script>
               <script src="js/jquery-3.0.0.min.js"></script>
               <!-- sidebar -->
               <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
               <script src="js/custom.js"></script>
               <!-- javascript -->
               <script src="js/owl.carousel.js"></script>
               <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
               <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
               <script>
                  $('#datepicker').datepicker({
                     uiLibrary: 'bootstrap4'
                  });
               </script>


</body>

</php>